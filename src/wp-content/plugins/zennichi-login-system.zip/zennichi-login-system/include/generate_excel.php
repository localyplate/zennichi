<?php

/*
 * write down here to export excel data
 * /generate-excel/にアクセスするとエクセルファイルがダウンロードできる。
 */

/** Include PHPExcel */
require_once dirname(__FILE__) . '/PHPExcel-develop/Classes/PHPExcel.php';

/** Include PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/PHPExcel-develop/Classes/PHPExcel/IOFactory.php';

/* replace user_meta_data */
require_once dirname(__FILE__) . '/lib/Template.php';

function ct_get_user_meta_data($user_id = 1) {

    $license_holder = get_user_meta($user_id, 'user_license_holder');
    $data['aaa'] = @$license_holder[0];

    $license_holder_det = get_user_meta($user_id, 'user_license_holder_det');
    $data['bbb'] = @$license_holder_det[0];

    $license_number = get_user_meta($user_id, 'user_license_number');
    $data['ccc'] = @$license_number[0];

//    $license_hokkaido = get_user_meta($user_id, 'user_license_hokkaido');
//    $license_pref = get_user_meta($user_id, 'user_license_pref');

    $license_year = get_user_meta($user_id, 'user_license_year');
    $data['ddd'] = @$license_year[0];

    $license_month = get_user_meta($user_id, 'user_license_month');
    $data['eee'] = @$license_month[0];

//    $license_day = get_user_meta($user_id, 'user_license_day');
//    $trade_name = get_user_meta($user_id, 'user_trade_name');
//    $trade_name_kana = get_user_meta($user_id, 'user_trade_name_kana');

    $office_pref = get_user_meta($user_id, 'user_office_pref');
    $data['hhh'] = @$office_pref[0];

//    $zip = get_user_meta($user_id, 'user_zip');

    $addr1 = get_user_meta($user_id, 'user_addr1');
    $addr2 = get_user_meta($user_id, 'user_addr2');
    $data['iii'] = @$addr1[0] . @$addr2[0];  // addr1+addr2

    $tel = get_user_meta($user_id, 'user_tel');
    $data['jjj'] = @$tel[0];

//    $minor_office = get_user_meta($user_id, 'user_minor_office');
//    $region = get_user_meta($user_id, 'user_region');
//    $branch_code = get_user_meta($user_id, 'user_branch_code');

    $representative_title = get_user_meta($user_id, 'user_representative_title');
    $data['kkk'] = @$representative_title[0];

    $representative = get_user_meta($user_id, 'user_representative');
    $data['lll'] = @$representative[0];

    $takuchi_pref = get_user_meta($user_id, 'user_takuchi_pref');
    $data['mmm'] = @$takuchi_pref[0];

    $takuchi_number = get_user_meta($user_id, 'user_takuchi_number');
    $data['nnn'] = @$takuchi_number[0];

    $takuchi_name = get_user_meta($user_id, 'user_takuchi_name');
    $data['ooo'] = @$takuchi_name[0];

    $takuchi_office_pref = get_user_meta($user_id, 'user_takuchi_office_pref');
    if (@$office_pref[0] != @$takuchi_office_pref[0]) {
        $data['ppp'] = @$takuchi_office_pref[0];
    } else {
        $data['ppp'] = '';
    }

    $takuchi_addr = get_user_meta($user_id, 'user_takuchi_addr');
    if ((@$addr1[0] . @$addr2[0]) != @$takuchi_addr[0]) {
        $data['qqq'] = @$takuchi_addr[0];
    } else {
        $data['qqq'] = '';
    }

    $takuchi_tel = get_user_meta($user_id, 'user_takuchi_tel');
    if (@$tel[0] != @$takuchi_tel[0]) {
        $data['rrr'] = @$takuchi_tel[0];
    } else {
        $data['rrr'] = '';
    }

    return $data;
}

function generate_data($template_id = '', $user_id = 0) {

    if (!isset($template_id) && $template_id == '') {
        return;
    }

    $template = dirname(__FILE__) . "/../tmp/" . $template_id . ".xlsx";

    /* read template */
    if (!file_exists($template)) {
        return;
    }

    $objPHPExcel = PHPExcel_IOFactory::load($template);

    /* get user_meta_data */
    if ($user_id == 0) {
        $user_id = get_current_user_id();
    }
    $data = ct_get_user_meta_data($user_id);

    foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {

        $worksheetTitle = $worksheet->getTitle();
        $highestRow = $worksheet->getHighestRow(); // e.g. 10
        $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);

        for ($row = 1; $row <= $highestRow; ++$row) {
            for ($col = 0; $col < $highestColumnIndex; ++$col) {

                $cell = $worksheet->getCellByColumnAndRow($col, $row);
                $val = $cell->getValue();

                $cell_name = $cell->getColumn() . $cell->getRow();
                if ($val != NULL) {
                    $val = new Template($val, $data);
                    $val->pattern = '%s';
                    $worksheet->setCellValue($cell_name, $val);
//                    $objPHPExcel->getActiveSheet()->setCellValue($cell_name, $value);
                }
            }
        }
    }

    return $objPHPExcel;
}

function generate_excel($template_id = '', $user_id = 0) {

    if (!isset($template_id) && $template_id == '') {
        return;
    }

    $template = dirname(__FILE__) . "/../tmp/" . $template_id . ".xlsx";

    /* read template */
    if (!file_exists($template)) {
        return;
    }

    $objPHPExcel = PHPExcel_IOFactory::load($template);

    /* get user_meta_data */
    if ($user_id == 0) {
        $user_id = get_current_user_id();
    }
    $data = ct_get_user_meta_data($user_id);

    foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {

        $worksheetTitle = $worksheet->getTitle();
        $highestRow = $worksheet->getHighestRow(); // e.g. 10
        $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);

        for ($row = 1; $row <= $highestRow; ++$row) {
            for ($col = 0; $col < $highestColumnIndex; ++$col) {

                $cell = $worksheet->getCellByColumnAndRow($col, $row);
                $val = $cell->getValue();

                $cell_name = $cell->getColumn() . $cell->getRow();
                if ($val != NULL) {
                    $val = new Template($val, $data);
                    $val->pattern = '%s';
                    $worksheet->setCellValue($cell_name, $val);
//                    $objPHPExcel->getActiveSheet()->setCellValue($cell_name, $value);
                }
            }
        }
    }

//     Rename worksheet
//    $objPHPExcel->getActiveSheet()->setTitle('Simple');
//     Set active sheet index to the first sheet, so Excel opens this as the first sheet
//    $objPHPExcel->setActiveSheetIndex(0);

    $xlsName = 'template-' . $user_id . '-' . microtime() . '.xlsx';

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8');
    header('Content-Disposition: attachment;filename="' . $xlsName . '"');
    header("Cache-Control: max-age=0");
    header("Pragma: public");
    header("Expires: 0");

//    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
//    $objWriter->save(dirname(__FILE__) . '/tmp/' . $xlsName);

    $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
//    $objWriter->setOffice2003Compatibility(true);

    $objWriter->save('php://output');
    exit();
}

function my_test() {

    $data = array('aaa' => 'le duong khang', 'bbb' => 'Q7');
    $val = 'Fullname aaa <br>Address bbb<br>Phone !!phone!!<br>Email ccc';

    $val = new Template($val, $data);
    $val->pattern = '%s';
    $val->clean = true;
    $val->clean_pattern = array('/ccc/');
    
    return $val;
}
