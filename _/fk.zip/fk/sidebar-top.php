     <aside>
      <div class="parts66">
       <img class="parts67" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/3.jpg" alt="" width="300" height="44">
       <img class="rabi" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/rabi-.png" alt="" width="94" height="151">
       <div>
        <div>
         <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_146.png" alt="" width="136" height="17">
         <a href="#"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_145.png" onmouseover="this.src='<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_145_on.png'" onmouseout="this.src='<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_145.png'" alt="会員ログイン" width="167" height="52" title="会員ログイン"></a>
         <div class="group">
          <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up.png" alt="" width="15" height="15">
          <p><a href="#">ログインの説明はコチラ</a></p>
         </div>
        </div>
       </div>
      </div>
      <div class="parts68">
       <a href="#" class="parts69"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_143.jpg" alt="" width="300" height="81"></a>
       <div class="module3 module3-0 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_7.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts70"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_141.jpg" alt="" width="300" height="81"></a>
       <div class="module3 module3-1 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="/magazine/" target="_blank" class="parts71"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_139.jpg" alt="" width="298" height="89"></a>
       <div class="module3 module3-2 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="/rabby_download/" target="_blank" class="parts72"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_137.png" alt="" width="299" height="89"></a>
       <div class="module3 module3-3 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts73"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_135.png" alt="" width="298" height="89"></a>
       <div class="module4 module4-0 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts74"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_133.jpg" alt="" width="298" height="89"></a>
       <div class="module4 module4-1 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts75"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_131.jpg" alt="" width="298" height="90"></a>
       <div class="module4 module4-2 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_7.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts76"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_129.jpg" alt="" width="298" height="90"></a>
       <div class="module5 module5-0 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_7.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts77"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_127.jpg" alt="" width="298" height="90"></a>
       <div class="module4 module4-3 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_7.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts78"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_125.png" alt="" width="298" height="177"></a>
       <div class="module4 module4-4 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts79"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_123.png" alt="" width="299" height="84"></a>
       <div class="module4 module4-5 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="http://www.fudousan.or.jp/" target="_blank" class="parts80"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_121.png" alt="" width="299" height="87"></a>
       <div class="module6 module6-0 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts81"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_119.png" alt="" width="300" height="82"></a>
       <div class="parts82 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="http://www.muryo-soudan.jp/" target="_blank" class="parts83"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_117.png" alt="" width="300" height="83"></a>
       <div class="module5 module5-1 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_11.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="#" class="parts831"><img class="parts84" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_115.jpg" alt="" width="300" height="84"></a>
       <div class="module6 module6-1 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_7.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="http://www.kindaika.jp/koshu/touroku/" target="_blank" class="parts832"><img class="parts85" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_113.png" alt="" width="300" height="86"></a>
       <div class="module4 module4-6 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_7.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="http://www.zennichi-jloan.jp/" target="_blank" class="parts833"><img class="parts86" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_111.png" alt="" width="299" height="87"></a>
       <div class="module7 module7-0 group">
        <img class="diff0-1" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_8.png" alt="" width="15" height="15">
        <p class="parts87">バナーの紹介文はいる。誘導文が入ります</p>
       </div>
       <a href="http://www.consul-e.net/" target="_blank" class="parts834"><img class="parts88" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_109.png" alt="" width="299" height="83"></a>
       <div class="module5 module5-2 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up_7.png" alt="" width="15" height="15">
        <p>バナーの紹介文はいる。誘導文が入ります</p>
       </div>
      </div>
     </aside>    </div>
   </div>