    <aside>
     <a class="parts11" href="#"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_35.jpg" alt="" width="300" height="81" class="parts03"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_5.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
     <a href="#" class="parts04"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_33.jpg" alt="" width="300" height="81"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_4.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
     <a href="#" class="parts05"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_31.jpg" alt="" width="300" height="89"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_5.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
     <a href="#" class="parts06"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_29.jpg" alt="" width="300" height="90"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_4.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
     <a href="#" class="parts07"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_27.jpg" alt="" width="300" height="90"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_4.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
     <a href="#" class="parts08"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_25.jpg" alt="" width="300" height="90"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_5.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
     <a href="/magazine/" target="_blank" class="parts09"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_23.jpg" alt="" width="300" height="90"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_5.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
     <a href="/rabby_download/" target="_blank" class="parts10"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/image_21.png" alt="" width="299" height="89"></a>
     <div class="module0 group">
      <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/about/arrow_up_4.png" alt="" width="15" height="15">
      <p>バナーの紹介文はいる。誘導文が入ります</p>
     </div>
    </aside> 