<form action="" method="post"> 

 <div id="keyboard">
        <div class="row0">
        <input class="kana_input" onclick="closekana()" name="a" type="button" value="ア">
        <input class="kana_input" onclick="closekana()" name="i" type="button" value="カ">
        <input class="kana_input" onclick="closekana()" name="u" type="button" value="サ">
        <input class="kana_input" onclick="closekana()" name="e" type="button" value="タ">
        <input class="kana_input" onclick="closekana()" name="o" type="button" value="ナ">
        <input class="kana_input" onclick="closekana()" name="o" type="button" value="ハ">
        <input class="kana_input" onclick="closekana()" name="o" type="button" value="マ">
        <input class="kana_input" onclick="closekana()" name="o" type="button" value="ヤ">
        <input class="kana_input" onclick="closekana()" name="o" type="button" value="ラ">
        <input class="kana_input" onclick="closekana()" name="o" type="button" value="ワ">
        </div>
        <div class="row0">
        <input class="kana_input" onclick="closekana()" name="ka" type="button" value="イ">
        <input class="kana_input" onclick="closekana()" name="ki" type="button" value="キ">
        <input class="kana_input" onclick="closekana()" name="ku" type="button" value="シ">
        <input class="kana_input" onclick="closekana()" name="ke" type="button" value="チ">
        <input class="kana_input" onclick="closekana()" name="ko" type="button" value="ニ">
        <input class="kana_input" onclick="closekana()" name="ko" type="button" value="ヒ">
        <input class="kana_input" onclick="closekana()" name="ko" type="button" value="ミ">
        <input class="kana_input" name="ko" type="button" value="　">
        <input class="kana_input" onclick="closekana()" name="ko" type="button" value="リ">
        <input class="kana_input" name="ko" type="button" value="　">
        </div>
        <div class="row0">
        <input class="kana_input" onclick="closekana()" name="sa" type="button" value="ウ">
        <input class="kana_input" onclick="closekana()" name="si" type="button" value="ク">
        <input class="kana_input" onclick="closekana()" name="su" type="button" value="ス">
        <input class="kana_input" onclick="closekana()" name="se" type="button" value="ツ">
        <input class="kana_input" onclick="closekana()" name="so" type="button" value="ヌ">
        <input class="kana_input" onclick="closekana()" name="so" type="button" value="フ">
        <input class="kana_input" onclick="closekana()" name="so" type="button" value="ム">
        <input class="kana_input" onclick="closekana()" name="so" type="button" value="ユ">
        <input class="kana_input" onclick="closekana()" name="so" type="button" value="ル">
        <input class="kana_input" onclick="closekana()" name="so" type="button" value="ヲ">
        </div>
        <div class="row0">
        <input class="kana_input" onclick="closekana()" name="ta" type="button" value="エ">
        <input class="kana_input" onclick="closekana()" name="ti" type="button" value="ケ">
        <input class="kana_input" onclick="closekana()" name="tu" type="button" value="セ">
        <input class="kana_input" onclick="closekana()" name="te" type="button" value="テ">
        <input class="kana_input" onclick="closekana()" name="to" type="button" value="ネ">
        <input class="kana_input" onclick="closekana()" name="to" type="button" value="ヘ">
        <input class="kana_input" onclick="closekana()" name="to" type="button" value="メ">
        <input class="kana_input" name="to" type="button" value="　">
        <input class="kana_input" onclick="closekana()" name="to" type="button" value="レ">
        <input class="kana_input" name="to" type="button" value="　">
        </div>
        <div class="row0">
        <input class="kana_input" onclick="closekana()" name="na" type="button" value="オ">
        <input class="kana_input" onclick="closekana()" name="ni" type="button" value="コ">
        <input class="kana_input" onclick="closekana()" name="nu" type="button" value="ソ">
        <input class="kana_input" onclick="closekana()" name="ne" type="button" value="ト">
        <input class="kana_input" onclick="closekana()" name="no" type="button" value="ノ">
        <input class="kana_input" onclick="closekana()" name="no" type="button" value="ホ">
        <input class="kana_input" onclick="closekana()" name="no" type="button" value="モ">
        <input class="kana_input" onclick="closekana()" name="no" type="button" value="ヨ">
        <input class="kana_input" onclick="closekana()" name="no" type="button" value="ロ">
        <input class="kana_input" onclick="closekana()" name="no" type="button" value="ン">
        </div>
        <div class="closekana" onclick="closekana()">閉じる</div>
</div>
</form>