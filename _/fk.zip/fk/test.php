<?php
/*
 * Template name: test
 */
?>
<html>
    <head></head>
    <body>
        <a href="/generate-excel/">EXPORT</a>
    </body>
</html>