   <footer>
    <div>
     <img class="footer-img-1" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_3.png" alt="" width="979" height="140">
     <a href="#wrap" class="pagetop"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_4.png" alt="" width="168" height="65"></a>
     <img class="footer-img-3" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_5.png" alt="" width="120" height="214">
     <div class="group">
      <div class="footer-div-3">
       <div class="group">
        <a href="<?php bloginfo('url'); ?>" alt="<?php bloginfo('name'); ?>"><img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_12.png" alt="" width="374" height="55"></a>
        <div>
         <div class="module7 module7-2 group">
          <img class="diff2-1" src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up.png" alt="" width="15" height="15">
          <p class="footer-p-1"><a href="#">サイトマップ</a></p>
         </div>
         <div class="footer-div-7 group">
          <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up.png" alt="" width="15" height="15">
          <p><a href="#">English Page</a></p>
         </div>
        </div>
       </div>
       <p>Copyright (C)2015 All Japan Real Estate Federation. All Rights Reserved.</p>
      </div>
      <div class="footer-div-8"></div>
      <div class="footer-div-9">
       <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/image_9.png" alt="" width="136" height="17">
       <a href="#"></a>
       <div class="footer-div-10 group">
        <img src="<?php bloginfo('url'); ?>/wp-content/themes/fk/images/top/arrow_up.png" alt="" width="15" height="15">
        <p><a href="#">ログインの説明はコチラ</a></p>
       </div>
      </div>
     </div>
    </div>
   </footer>
   <form id="auto-generated-form" action="yourHandler"></form>
  </div>
  <script type='text/javascript' src='<?php bloginfo('url'); ?>/wp-includes/js/admin-bar.min.js?ver=4.1.1'></script>
	<script type="text/javascript">
		(function() {
			var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');

			request = true;

			b[c] = b[c].replace( rcs, ' ' );
			b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
		}());
	</script>
			<div id="wpadminbar" class="nojq nojs" role="navigation">
			<a class="screen-reader-shortcut" href="#wp-toolbar" tabindex="1">ツールバーへスキップ</a>
			<div class="quicklinks" id="wp-toolbar" role="navigation" aria-label="トップナビゲーションのツールバー。" tabindex="0">
				<ul id="wp-admin-bar-root-default" class="ab-top-menu">
		<li id="wp-admin-bar-wp-logo" class="menupop"><a class="ab-item"  aria-haspopup="true" href="<?php bloginfo('url'); ?>/wp-admin/about.php" title="WordPress について"><span class="ab-icon"></span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-wp-logo-default" class="ab-submenu">
		<li id="wp-admin-bar-about"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/about.php">WordPress について</a>		</li></ul><ul id="wp-admin-bar-wp-logo-external" class="ab-sub-secondary ab-submenu">
		<li id="wp-admin-bar-wporg"><a class="ab-item"  href="https://ja.wordpress.org/">WordPress.org</a>		</li>
		<li id="wp-admin-bar-documentation"><a class="ab-item"  href="http://wpdocs.sourceforge.jp/">ドキュメンテーション</a>		</li>
		<li id="wp-admin-bar-support-forums"><a class="ab-item"  href="http://ja.forums.wordpress.org/">サポートフォーラム</a>		</li>
		<li id="wp-admin-bar-feedback"><a class="ab-item"  href="http://ja.forums.wordpress.org/forum/2">フィードバック</a>		</li></ul></div>		</li>
		<li id="wp-admin-bar-my-sites" class="menupop"><a class="ab-item"  aria-haspopup="true" href="<?php bloginfo('url'); ?>/wp-admin/my-sites.php">参加サイト</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-my-sites-super-admin" class="ab-submenu">
		<li id="wp-admin-bar-network-admin" class="menupop"><a class="ab-item"  aria-haspopup="true" href="<?php bloginfo('url'); ?>/wp-admin/network/">サイトネットワーク管理者</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-network-admin-default" class="ab-submenu">
		<li id="wp-admin-bar-network-admin-d"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/network/">ダッシュボード</a>		</li>
		<li id="wp-admin-bar-network-admin-s"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/network/sites.php">サイト</a>		</li>
		<li id="wp-admin-bar-network-admin-u"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/network/users.php">ユーザー</a>		</li>
		<li id="wp-admin-bar-network-admin-t"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/network/themes.php">テーマ</a>		</li>
		<li id="wp-admin-bar-network-admin-p"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/network/plugins.php">プラグイン</a>		</li></ul></div>		</li></ul><ul id="wp-admin-bar-my-sites-list" class="ab-sub-secondary ab-submenu">
		<li id="wp-admin-bar-blog-1" class="menupop"><a class="ab-item"  aria-haspopup="true" href="<?php bloginfo('url'); ?>/wp-admin/"><div class="blavatar"></div>公益社団法人　全日本不動産協会</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-blog-1-default" class="ab-submenu">
		<li id="wp-admin-bar-blog-1-d"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/">ダッシュボード</a>		</li>
		<li id="wp-admin-bar-blog-1-n"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/post-new.php">新規投稿</a>		</li>
		<li id="wp-admin-bar-blog-1-c"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/edit-comments.php">コメント管理</a>		</li>
		<li id="wp-admin-bar-blog-1-v"><a class="ab-item"  href="<?php bloginfo('url'); ?>/">サイトを表示</a>		</li></ul></div>		</li></ul></div>		</li>
		<li id="wp-admin-bar-site-name" class="menupop"><a class="ab-item"  aria-haspopup="true" href="<?php bloginfo('url'); ?>/wp-admin/">公益社団法人　全日本不動産協会</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-site-name-default" class="ab-submenu">
		<li id="wp-admin-bar-dashboard"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/">ダッシュボード</a>		</li></ul><ul id="wp-admin-bar-appearance" class="ab-submenu">
		<li id="wp-admin-bar-themes"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/themes.php">テーマ</a>		</li>
		<li id="wp-admin-bar-customize" class="hide-if-no-customize"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/customize.php?url=http%3A%2F%2Fzennichi.platetec.com%2F">カスタマイズ</a>		</li></ul></div>		</li>
		<li id="wp-admin-bar-updates"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/network/update-core.php" title="1件の WordPress 更新, 5件のプラグイン更新, 1件のテーマ更新"><span class="ab-icon"></span><span class="ab-label">7</span><span class="screen-reader-text">1件の WordPress 更新, 5件のプラグイン更新, 1件のテーマ更新</span></a>		</li>
		<li id="wp-admin-bar-comments"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/edit-comments.php" title="0件のコメントが承認待ちです。"><span class="ab-icon"></span><span id="ab-awaiting-mod" class="ab-label awaiting-mod pending-count count-0">0</span></a>		</li>
		<li id="wp-admin-bar-new-content" class="menupop"><a class="ab-item"  aria-haspopup="true" href="<?php bloginfo('url'); ?>/wp-admin/post-new.php" title="新規追加"><span class="ab-icon"></span><span class="ab-label">新規</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-new-content-default" class="ab-submenu">
		<li id="wp-admin-bar-new-post"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/post-new.php">投稿</a>		</li>
		<li id="wp-admin-bar-new-media"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/media-new.php">メディア</a>		</li>
		<li id="wp-admin-bar-new-page"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/post-new.php?post_type=page">固定ページ</a>		</li>
		<li id="wp-admin-bar-new-user"><a class="ab-item"  href="<?php bloginfo('url'); ?>/wp-admin/user-new.php">ユーザー</a>		</li></ul></div>		</li></ul><ul id="wp-admin-bar-top-secondary" class="ab-top-secondary ab-top-menu">
		<li id="wp-admin-bar-search" class="admin-bar-search"><div class="ab-item ab-empty-item" tabindex="-1"><form action="<?php bloginfo('url'); ?>/" method="get" id="adminbarsearch"><input class="adminbar-input" name="s" id="adminbar-search" type="text" value="" maxlength="150" /><input type="submit" class="adminbar-button" value="検索"/></form></div>		</li>
		<li id="wp-admin-bar-my-account" class="menupop with-avatar"><a class="ab-item"  aria-haspopup="true" href="<?php bloginfo('url'); ?>/your-profile/" title="アカウント">こんにちは、root さん !<img alt='' src='http://0.gravatar.com/avatar/c0396e8cae84ae92324197aacdef3853?s=26&amp;d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D26&amp;r=G' class='avatar avatar-26 photo' height='26' width='26' /></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-user-actions" class="ab-submenu">
		<li id="wp-admin-bar-user-info"><a class="ab-item" tabindex="-1" href="<?php bloginfo('url'); ?>/your-profile/"><img alt='' src='http://0.gravatar.com/avatar/c0396e8cae84ae92324197aacdef3853?s=64&amp;d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D64&amp;r=G' class='avatar avatar-64 photo' height='64' width='64' /><span class='display-name'>root</span></a>		</li>
		<li id="wp-admin-bar-edit-profile"><a class="ab-item"  href="<?php bloginfo('url'); ?>/your-profile/">プロフィールを編集</a>		</li>
		<li id="wp-admin-bar-logout"><a class="ab-item"  href="<?php bloginfo('url'); ?>/logout/?_wpnonce=27bbfffa98">ログアウト</a>		</li></ul></div>		</li></ul>			</div>
						<a class="screen-reader-shortcut" href="<?php bloginfo('url'); ?>/logout/?_wpnonce=27bbfffa98">ログアウト</a>
					</div>
<?php wp_footer(); ?>
		 </body>
</html>